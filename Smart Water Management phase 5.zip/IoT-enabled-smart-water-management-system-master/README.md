# IoT-enabled-smart-water-management-system

This project includes remote controlling and monitoring of water usage providing an efficient platform for analysis of water consumption throughout the city.

Components Used:

1. NodeMCU
2. Water Flow Sensor
3. pH Sensor
4. DC Water Pump
5. ULtrasonic Level Sensor

IoT platform Used:
1. CloudMQTT
